package com.mygdx.arkadroid.screen;

import com.badlogic.gdx.Application;
import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.ScreenAdapter;
import com.badlogic.gdx.graphics.GL20;
import com.badlogic.gdx.graphics.OrthographicCamera;
import com.mygdx.arkadroid.game.Arkadroid;
import com.mygdx.arkadroid.game.GameWorld;
import com.mygdx.arkadroid.model.Assets;
import com.mygdx.arkadroid.model.Bar;
import com.mygdx.arkadroid.model.Settings;

public class GameScreen extends ScreenAdapter {

    public static final int GAME_READY = 0;
    public static final int GAME_RUNNING = 1;
    public static final int GAME_LEVEL_END = 2;
    public static final int GAME_OVER = 3;

    private final int width;
    private final int height;
    private final OrthographicCamera guiCam;
    private Bar bar;
    public Arkadroid game;
    private int state;
    private GameWorld world;
    private GameWorldRenderer renderer;
    private int[] highscores;
    private String[] players;

    public GameScreen (Arkadroid game, int level) {

        this.game = game;

        width = game.width;
        height = game.height;

        guiCam = new OrthographicCamera(width, height);
        guiCam.position.set(width/2, height/2, 0);

        world = new GameWorld(game, level);
        renderer = new GameWorldRenderer(game.batch, world);

        bar = new Bar(3*width/8, 2*height/16, width/4, Assets.bar.getRegionHeight()*width/4/Assets.bar.getRegionWidth());

        renderer = new GameWorldRenderer(game.batch, world);

        highscores = Settings.highscores;
        players = Settings.players;

        state = GAME_READY;
        world.state = GameWorld.WORLD_STATE_READY;

        Assets.playMusic(Assets.gameTheme);

    }

    public void update (float deltaTime) {
        if (deltaTime > 0.1f) deltaTime = 0.1f;

        switch (state) {
            case GAME_READY:
                updateReady(deltaTime);
                break;
            case GAME_RUNNING:
                updateRunning(deltaTime);
                break;
            case GAME_LEVEL_END:
                updateLevelEnd();
                break;
            case GAME_OVER:
                updateGameOver();
                break;
        }
    }

    private void updateReady(float deltaTime) {
        if(Gdx.input.isTouched()) {
            world.state = GameWorld.WORLD_STATE_RUNNING;
        }
        Application.ApplicationType appType = Gdx.app.getType();
        if(appType == Application.ApplicationType.Android)
            world.update(deltaTime, Gdx.input.getAccelerometerX());
    }

    private void updateRunning(float deltaTime) {

        Application.ApplicationType appType = Gdx.app.getType();
        if(appType == Application.ApplicationType.Android)
            world.update(deltaTime, Gdx.input.getAccelerometerX());
        if (world.state == GameWorld.WORLD_STATE_NEXT_LEVEL)
            state = GAME_LEVEL_END;

    }

    private void updateLevelEnd() {

        int p = checkHighscore();
        if(p>0) {
            if(Gdx.input.isTouched()) {
                game.setScreen(new NameScreen(game, world.score));
                this.dispose();
            }
        }
        else {
            if(Gdx.input.isTouched()) {
                game.setScreen(new MainMenuScreen(game));
            }
        }

    }

    private void updateGameOver() {

        presentGameOver();
        if(Gdx.input.isTouched()) {
            game.setScreen(new MainMenuScreen(game));
            this.dispose();
        }

    }

    public void draw () {

        GL20 gl = Gdx.gl;
        gl.glClearColor(1, 0, 0, 1);
        gl.glClear(GL20.GL_COLOR_BUFFER_BIT);

        renderer.render();

        guiCam.update();
        game.batch.setProjectionMatrix(guiCam.combined);

        game.batch.enableBlending();
        game.batch.begin();
        switch (state) {
            case GAME_READY:
                presentReady();
                break;
            case GAME_RUNNING:
                presentRunning();
                break;
            case GAME_LEVEL_END:
                presentLevelEnd();
                int p = checkHighscore();
                if(p>0)
                    presentScore(p);
                break;
            case GAME_OVER:
                presentGameOver();
                break;
        }
        game.batch.end();

    }

    private void presentReady() {

        Assets.font.draw(game.batch, "READY", width-20, height/2);

    }

    private void presentRunning() {

        Assets.font_small.draw(game.batch, "Life x" + world.lives, 20, 19 * height / 20);
        Assets.font_small.draw(game.batch, "" + (int) world.time, 2 * width / 6, 19 * height / 20);
        Assets.font_small.draw(game.batch, "Score: "+world.score, 4*width/6-60, 19*height/20);

    }

    private void presentLevelEnd() {

        Assets.font.draw(game.batch, "WINNER!!", width-20, 3*height/8);

    }

    private void presentGameOver() {

        Assets.font.draw(game.batch, "GAME OVER", width-20, 3*height/8);
        Assets.font.draw(game.batch, "NO SCORE FOR YOU", width - 20, 4 * height / 8);
    }

    private void presentScore(int p) {

        Assets.font.draw(game.batch, "GOOD JOB!", width-20, 4*height/8);
        Assets.font.draw(game.batch, "#"+p+" "+world.score+"pts", width-20, 5*height/8);

    }

    private int checkHighscore() {

        if(world.score > highscores[9])
            for(int i=10; i>0; i--) {
                if(world.score < highscores[i])
                    return i-1;
            }

        return -1;

    }

    public void render(float delta) {

        update(delta);
        draw();


    }



}
