package com.mygdx.arkadroid.model;

import com.badlogic.gdx.graphics.g2d.TextureRegion;

public class Brick extends GameObject {

    public static final int RED = 0;
    public static final int BLUE = 1;
    public static final int GREEN = 2;
    public static final int YELLOW = 3;
    public static final int GREY = 4;
    public static final int BLACK = 5;

    public int color;
    public TextureRegion texture;

    public Brick(float x, float y, float width, float height, int color) {

        super(x, y, width, height);
        this.color = color;

        switch(color) {
            case 0:
                texture = Assets.redBrick;
                break;
            case 1:
                texture = Assets.blueBrick;
                break;
            case 2:
                texture = Assets.greenBrick;
                break;
            case 3:
                texture = Assets.yellowBrick;
                break;
            case 4:
                texture = Assets.darkStoneBrick;
                break;
            case 5:
                texture = Assets.blackBrick;
                break;
        }

    }
}
