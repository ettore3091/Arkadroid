package com.mygdx.arkadroid.model;

import com.badlogic.gdx.math.Rectangle;
import com.badlogic.gdx.math.Vector3;
import com.mygdx.arkadroid.game.Arkadroid;

import java.util.ArrayList;

public class Keyboard {

    public ArrayList<Key> keyboard;
    private char[] symbols = {'A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J', 'K', 'L', 'M', 'N',
                              'O', 'P', 'Q', 'R', 'S', 'T', 'U', 'V', 'W', 'X', 'Y', 'Z'};

    public Keyboard(Arkadroid game) {

        int s =0;
        for(int i=0; i<4; i++) {
            for(int j=0; j<8; j++) {
                keyboard.add(new Key(symbols[s], new Rectangle(5+game.width/9*i, 7*game.height/8-game.height/8*j,
                                                               game.width/9, game.height/8)));
            }
        }
    }

    public Key type(Vector3 touchPoint) {

        for(int i=0; i<keyboard.size(); i++) {
            if(keyboard.get(i).isPressed(touchPoint))
                return keyboard.get(i);
        }

        return null;

    }

}
