package com.mygdx.arkadroid.model;

import com.badlogic.gdx.math.Vector2;


public class Bar extends DynamicGameObject {

    private float[] sections;

    public Bar(float x, float y, float width, float height) {

        super(x,y,width,height);
        sections = new float[8];
        float swidth = (width-width*0.16f)/7;
        sections[0] =width*0.08f;
        for(int i=1; i<8; i++) {
            sections[i]= sections[0]+i*swidth;
        }

    }

    public Vector2 ballDirection(float x) {

        int i=0;
        while(i<8&& x > sections[i]) {
            i++;
        }
        switch(i) {
            case 0:
                return new Vector2(-0.8f, 0.2f);
            case 1:
                return new Vector2(-0.6f, 0.4f);
            case 2:
                return new Vector2(-0.4f, 0.6f);
            case 3:
                return new Vector2(-0.2f, 0.8f);
            case 4:
                return new Vector2(0f, 1f);
            case 5:
                return new Vector2(0.2f, 0.8f);
            case 6:
                return new Vector2(0.4f, 0.6f);
            case 7:
                return new Vector2(0.6f, 0.4f);
            case 8:
                return new Vector2(-0.8f, 0.2f);
            default:
                return new Vector2(0f,0f);
        }

    }

    public void update (float move) {

        position.x += move;
        bounds.x = (int)position.x;

    }

}
